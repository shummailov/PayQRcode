# CryptoWallet Application

## Overview

This is a modern cryptocurrency wallet application built with React and Express.js with Telegram bot integration. The application provides a mobile-first interface for managing multiple cryptocurrency wallets, viewing balances, sending/receiving transactions, and tracking transaction history. It features a secure PIN-based authentication system and supports Bitcoin, Ethereum, and USDC. Users can access the wallet through a web interface or directly from Telegram using the bot.

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Changes

- ✅ Added Telegram bot integration with python-telegram-bot
- ✅ Implemented Telegram WebApp support for seamless user experience
- ✅ Added automatic user creation for Telegram users
- ✅ Created initial wallet setup for new Telegram users
- ✅ Fixed TypeScript errors in storage layer
- ✅ Added proper session management for Telegram users
- ✅ Updated HTML meta tags for better social sharing

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **UI Library**: Radix UI primitives with shadcn/ui components
- **Styling**: Tailwind CSS with custom CSS variables for theming
- **State Management**: TanStack Query (React Query) for server state
- **Routing**: Wouter for lightweight client-side routing
- **Build Tool**: Vite with React plugin

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Database**: PostgreSQL with Drizzle ORM (configured but using in-memory storage for demo)
- **Database Provider**: Neon Database (serverless PostgreSQL)
- **Session Management**: Express sessions with PostgreSQL store support
- **API Design**: RESTful endpoints for user, wallet, and transaction operations

### Mobile-First Design
- Responsive design optimized for mobile devices
- Touch-friendly interface with gesture support
- Bottom navigation for easy thumb navigation
- Glass morphism effects for modern aesthetics

## Key Components

### Authentication System
- PIN-based authentication (4-digit numeric PIN)
- Session management for authenticated state
- Demo user with PIN "1234" for testing

### Wallet Management
- Multi-currency wallet support (BTC, ETH, USDC)
- Real-time balance display with USD conversion
- Wallet address generation and management
- Private key storage (demo implementation)

### Transaction System
- Send/receive cryptocurrency functionality
- Transaction history with status tracking
- Network fee calculation
- Transaction status updates (pending, confirmed, failed)

### UI Components
- Reusable component library based on Radix UI
- Custom crypto-themed styling
- Loading states and error handling
- Toast notifications for user feedback

## Data Flow

### User Authentication Flow
1. User enters 4-digit PIN
2. PIN verification against stored user data
3. Session establishment upon successful authentication
4. Access to wallet functionality

### Transaction Flow
1. User initiates send/receive transaction
2. Form validation and address verification
3. Transaction creation with pending status
4. Network fee calculation
5. Transaction submission and status updates
6. Balance updates and history refresh

### Data Synchronization
- Real-time price updates every minute
- Automatic balance refreshes after transactions
- Transaction history updates
- Optimistic UI updates with error handling

## External Dependencies

### Core Libraries
- **React Ecosystem**: React 18, React DOM, TanStack Query
- **UI Components**: Radix UI primitives, Lucide React icons
- **Styling**: Tailwind CSS, class-variance-authority, clsx
- **Forms**: React Hook Form with Zod validation
- **Date Handling**: date-fns for formatting
- **Database**: Drizzle ORM with PostgreSQL adapter

### Development Tools
- **Build Tools**: Vite, esbuild for production builds
- **TypeScript**: Full TypeScript support across the stack
- **Development**: tsx for running TypeScript files directly
- **Replit Integration**: Replit-specific plugins for development

### External Services
- **Database**: Neon Database (serverless PostgreSQL)
- **Price Data**: Mock price service (would integrate with real crypto APIs)
- **Network Integration**: Mock blockchain interactions (would integrate with actual networks)

## Deployment Strategy

### Development Environment
- Vite dev server with HMR for frontend
- Express server with tsx for backend
- In-memory storage for rapid development
- Replit-optimized configuration

### Production Build
- Frontend: Vite production build with code splitting
- Backend: esbuild bundling for Node.js
- Database: PostgreSQL with Drizzle migrations
- Static asset serving through Express

### Environment Configuration
- Environment variables for database connection
- Separate configurations for development/production
- Database URL management through environment variables
- Secure session configuration for production

### Scalability Considerations
- Stateless backend design for horizontal scaling
- Database connection pooling
- Session storage in PostgreSQL for multi-instance deployment
- API rate limiting and security measures ready for implementation

## Security Features

### Data Protection
- PIN-based authentication
- Session management with secure cookies
- Private key encryption (demo implementation)
- Input validation and sanitization

### API Security
- Request validation using Zod schemas
- Error handling without sensitive data exposure
- CORS configuration for frontend-backend communication
- Rate limiting ready for production implementation

This architecture provides a solid foundation for a cryptocurrency wallet application with room for scaling and additional security features as needed.