# CryptoWallet - Telegram Mini App

A secure cryptocurrency wallet web application with Telegram bot integration, supporting Bitcoin, Ethereum, and USDC.

## Features

### Web Application
- 🔐 **PIN-based Authentication** - Secure 4-digit PIN login
- 💰 **Multi-Currency Support** - Bitcoin (BTC), Ethereum (ETH), USD Coin (USDC)
- 📊 **Real-time Prices** - Live cryptocurrency price tracking
- 💸 **Send & Receive** - Easy crypto transactions with QR codes
- 📱 **Mobile-First Design** - Optimized for mobile devices
- 📈 **Transaction History** - Complete transaction records and status
- 🎨 **Modern UI** - Glass morphism effects and smooth animations

### Telegram Bot
- 🚀 **Web App Integration** - Launch wallet directly from Telegram
- ❓ **Help & Support** - Built-in support and FAQ system
- 🔒 **Security Information** - Security features and refund policy
- ⚙️ **Settings Management** - Account settings and preferences

## Quick Start

### 1. Web Application
```bash
npm install
npm run dev
```

The web app will be available at `http://localhost:5000`

**Demo Credentials:**
- PIN: `1234`

### 2. Telegram Bot Setup

1. **Create a Telegram Bot:**
   - Message [@BotFather](https://t.me/BotFather) on Telegram
   - Use `/newbot` command and follow instructions
   - Save your bot token

2. **Set Environment Variable:**
   ```bash
   export TELEGRAM_BOT_TOKEN="your_bot_token_here"
   ```

3. **Update Web App URL:**
   - Edit `telegram_bot.py`
   - Replace `https://your-app.replit.app` with your actual app URL

4. **Run the Bot:**
   ```bash
   python telegram_bot.py
   ```

## Architecture

### Frontend (React + TypeScript)
- **Framework:** React 18 with TypeScript
- **UI Library:** Radix UI + shadcn/ui components
- **Styling:** Tailwind CSS with custom crypto themes
- **State Management:** TanStack Query for server state
- **Routing:** Wouter for client-side routing

### Backend (Express.js)
- **Framework:** Express.js with TypeScript
- **Database:** In-memory storage (demo) / PostgreSQL (production)
- **ORM:** Drizzle ORM with Zod validation
- **Authentication:** Session-based with PIN verification

### Telegram Bot (Python)
- **Library:** python-telegram-bot
- **Features:** Inline keyboards, web app integration
- **Deployment:** Can run alongside the web app

## API Endpoints

### Authentication
- `POST /api/auth/verify-pin` - Verify user PIN

### Wallets
- `GET /api/wallets/:userId` - Get user wallets
- `GET /api/prices` - Get current crypto prices

### Transactions
- `GET /api/transactions/:userId` - Get user transactions
- `POST /api/transactions` - Create new transaction

## Development

### Prerequisites
- Node.js 20+
- Python 3.8+ (for Telegram bot)

### Install Dependencies
```bash
# Web application
npm install

# Telegram bot
pip install python-telegram-bot
```

### Environment Variables
```bash
# Telegram Bot (required for bot)
TELEGRAM_BOT_TOKEN=your_bot_token_here

# Database (optional, uses in-memory by default)
DATABASE_URL=postgresql://...
```

### Running in Development
```bash
# Start web application
npm run dev

# Start Telegram bot (in separate terminal)
python telegram_bot.py
```

## Deployment

### Web Application
The app is configured for Replit deployment:
1. Push to your Replit project
2. Set environment variables in Replit Secrets
3. Use "Deploy" button for production deployment

### Telegram Bot
The bot can run on any Python hosting service:
- Replit (recommended)
- Heroku
- Railway
- DigitalOcean App Platform

## Security Features

- ✅ PIN-based authentication
- ✅ Session management
- ✅ Input validation with Zod schemas
- ✅ CORS protection
- ✅ Error handling without data exposure
- ✅ Mock private key encryption (demo)

## Demo Data

The application includes demo data for testing:
- **User:** demo_user (PIN: 1234)
- **Wallets:** BTC, ETH, USDC with sample balances
- **Transactions:** Sample transaction history

## Production Considerations

### Security
- [ ] Implement real cryptographic functions
- [ ] Add rate limiting
- [ ] Enable HTTPS/TLS
- [ ] Add proper private key encryption
- [ ] Implement 2FA

### Database
- [ ] Switch to PostgreSQL
- [ ] Add database migrations
- [ ] Implement connection pooling
- [ ] Add backup strategy

### Monitoring
- [ ] Add error tracking (Sentry)
- [ ] Implement logging
- [ ] Add performance monitoring
- [ ] Health check endpoints

## Support

For questions or issues:
- 📧 Email: support@example.com
- 💬 Telegram: @YourSupportBot
- 📝 Issues: GitHub Issues

## License

MIT License - see LICENSE file for details.