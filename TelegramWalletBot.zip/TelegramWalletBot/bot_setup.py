#!/usr/bin/env python3
"""
Telegram Bot Setup Script for CryptoWallet

This script helps you set up the Telegram bot for your CryptoWallet application.
"""

import os
import sys

def check_token():
    """Check if bot token is configured"""
    token = os.getenv("TELEGRAM_BOT_TOKEN")
    if not token or token == "YOUR_BOT_TOKEN_HERE":
        print("❌ Bot token not found!")
        print("\nTo set up your Telegram bot:")
        print("1. Message @BotFather on Telegram")
        print("2. Use /newbot command and follow instructions")
        print("3. Copy your bot token")
        print("4. Set environment variable:")
        print("   export TELEGRAM_BOT_TOKEN='your_token_here'")
        print("5. Run this script again")
        return False
    
    print(f"✅ Bot token found: {token[:10]}...")
    return True

def check_dependencies():
    """Check if required dependencies are installed"""
    try:
        import telegram
        print("✅ python-telegram-bot is installed")
        return True
    except ImportError:
        print("❌ python-telegram-bot not installed")
        print("Run: pip install python-telegram-bot")
        return False

def update_bot_url():
    """Update the web app URL in the bot"""
    current_url = "https://cryptowallet-app.replit.app"
    print(f"🔗 Current web app URL: {current_url}")
    
    new_url = input("Enter your Replit app URL (or press Enter to keep current): ").strip()
    if new_url:
        # Update the URL in telegram_bot.py
        try:
            with open("telegram_bot.py", "r") as f:
                content = f.read()
            
            content = content.replace(current_url, new_url)
            
            with open("telegram_bot.py", "w") as f:
                f.write(content)
            
            print(f"✅ Updated web app URL to: {new_url}")
        except Exception as e:
            print(f"❌ Failed to update URL: {e}")
    else:
        print("✅ Keeping current URL")

def test_bot():
    """Test if the bot can start"""
    if not check_token():
        return False
    
    try:
        from telegram_bot import main
        print("🤖 Starting bot test...")
        print("✅ Bot configuration is valid!")
        print("To start the bot, run: python telegram_bot.py")
        return True
    except Exception as e:
        print(f"❌ Bot test failed: {e}")
        return False

def main():
    """Main setup function"""
    print("🚀 CryptoWallet Telegram Bot Setup")
    print("=" * 40)
    
    # Check dependencies
    if not check_dependencies():
        sys.exit(1)
    
    # Check token
    if not check_token():
        sys.exit(1)
    
    # Update URL
    update_bot_url()
    
    # Test bot
    if test_bot():
        print("\n🎉 Setup complete!")
        print("Your Telegram bot is ready to use.")
        print("\nNext steps:")
        print("1. Run: python telegram_bot.py")
        print("2. Find your bot on Telegram and send /start")
        print("3. Click 'Open Wallet' to test the integration")
    else:
        print("\n❌ Setup failed. Please check the errors above.")

if __name__ == "__main__":
    main()