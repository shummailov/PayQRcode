#!/usr/bin/env python3
"""
Test script for the CryptoWallet Telegram bot
"""

import asyncio
import os
from telegram import Bot

async def test_bot():
    """Test the bot configuration"""
    token = "7684847636:AAH93tlzw-o-HeJM_j1s6sUAAhiuewJ_VEo"
    bot = Bot(token=token)
    
    try:
        # Get bot information
        bot_info = await bot.get_me()
        print(f"✅ Bot is active!")
        print(f"   Name: {bot_info.first_name}")
        print(f"   Username: @{bot_info.username}")
        print(f"   Bot ID: {bot_info.id}")
        
        # Test webhook info
        webhook_info = await bot.get_webhook_info()
        print(f"\n📡 Webhook Status:")
        print(f"   URL: {webhook_info.url or 'Not set (using polling)'}")
        print(f"   Pending updates: {webhook_info.pending_update_count}")
        
        print(f"\n🚀 Ready to test!")
        print(f"   1. Open Telegram and search for @{bot_info.username}")
        print(f"   2. Send /start to the bot")
        print(f"   3. Click 'Open Wallet' to test the web app integration")
        print(f"   4. Set PIN: 1234 (for demo user) or any 4-digit PIN (for new users)")
        
        return True
        
    except Exception as e:
        print(f"❌ Bot test failed: {e}")
        return False

if __name__ == "__main__":
    asyncio.run(test_bot())