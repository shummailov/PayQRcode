import { users, wallets, transactions, type User, type InsertUser, type Wallet, type InsertWallet, type Transaction, type InsertTransaction } from "@shared/schema";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByTelegramId(telegramId: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserPin(userId: number, pin: string): Promise<void>;

  // Wallet operations
  getUserWallets(userId: number): Promise<Wallet[]>;
  getWallet(id: number): Promise<Wallet | undefined>;
  createWallet(wallet: InsertWallet): Promise<Wallet>;
  updateWalletBalance(walletId: number, balance: string): Promise<void>;
  createInitialWallets(userId: number): Promise<void>;

  // Transaction operations
  getUserTransactions(userId: number): Promise<Transaction[]>;
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;
  updateTransactionStatus(transactionId: number, status: string, txHash?: string): Promise<void>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private wallets: Map<number, Wallet>;
  private transactions: Map<number, Transaction>;
  private currentUserId: number;
  private currentWalletId: number;
  private currentTransactionId: number;

  constructor() {
    this.users = new Map();
    this.wallets = new Map();
    this.transactions = new Map();
    this.currentUserId = 1;
    this.currentWalletId = 1;
    this.currentTransactionId = 1;

    // Initialize with demo data
    this.initializeDemoData();
  }

  private async initializeDemoData() {
    // Create demo user
    const demoUser = await this.createUser({
      username: "demo_user",
      telegramId: "12345",
      pin: "1234"
    });

    // Auto-create initial wallets for new Telegram users when they set their PIN
    await this.createInitialWallets(demoUser.id);

  }

  async createInitialWallets(userId: number): Promise<void> {
    // Create demo wallets
    await this.createWallet({
      userId: userId,
      address: "bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh",
      privateKey: "mock_private_key_btc",
      currency: "BTC",
      balance: "0.2847"
    });

    await this.createWallet({
      userId: userId,
      address: "0x742d35Cc6e9e1f0d5c8b9fcA9D6FfB1f4b8D2a1E",
      privateKey: "mock_private_key_eth",
      currency: "ETH",
      balance: "2.15"
    });

    await this.createWallet({
      userId: userId,
      address: "0x742d35Cc6e9e1f0d5c8b9fcA9D6FfB1f4b8D2a1E",
      privateKey: "mock_private_key_usdc",
      currency: "USDC",
      balance: "600.00"
    });

    // Create demo transactions for demo user
    await this.createTransaction({
      userId: userId,
      toAddress: "bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh",
      amount: "0.0125",
      currency: "BTC",
      type: "receive",
      status: "confirmed",
      txHash: "0x123abc...",
      networkFee: "0.00002"
    });

    await this.createTransaction({
      userId: userId,
      fromAddress: "0x742d35Cc6e9e1f0d5c8b9fcA9D6FfB1f4b8D2a1E",
      toAddress: "0x456def...",
      amount: "0.5",
      currency: "ETH",
      type: "send",
      status: "confirmed",
      txHash: "0x456def...",
      networkFee: "0.002"
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async getUserByTelegramId(telegramId: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.telegramId === telegramId);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { 
      ...insertUser, 
      id, 
      telegramId: insertUser.telegramId || null,
      createdAt: new Date()
    };
    this.users.set(id, user);
    return user;
  }

  async updateUserPin(userId: number, pin: string): Promise<void> {
    const user = this.users.get(userId);
    if (user) {
      user.pin = pin;
      this.users.set(userId, user);
    }
  }

  async getUserWallets(userId: number): Promise<Wallet[]> {
    return Array.from(this.wallets.values()).filter(wallet => wallet.userId === userId);
  }

  async getWallet(id: number): Promise<Wallet | undefined> {
    return this.wallets.get(id);
  }

  async createWallet(insertWallet: InsertWallet): Promise<Wallet> {
    const id = this.currentWalletId++;
    const wallet: Wallet = { 
      ...insertWallet, 
      id,
      balance: insertWallet.balance || "0"
    };
    this.wallets.set(id, wallet);
    return wallet;
  }

  async updateWalletBalance(walletId: number, balance: string): Promise<void> {
    const wallet = this.wallets.get(walletId);
    if (wallet) {
      wallet.balance = balance;
      this.wallets.set(walletId, wallet);
    }
  }

  async getUserTransactions(userId: number): Promise<Transaction[]> {
    return Array.from(this.transactions.values())
      .filter(transaction => transaction.userId === userId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async createTransaction(insertTransaction: InsertTransaction): Promise<Transaction> {
    const id = this.currentTransactionId++;
    const transaction: Transaction = { 
      ...insertTransaction, 
      id, 
      status: insertTransaction.status || "pending",
      fromAddress: insertTransaction.fromAddress || null,
      txHash: insertTransaction.txHash || null,
      networkFee: insertTransaction.networkFee || null,
      createdAt: new Date()
    };
    this.transactions.set(id, transaction);
    return transaction;
  }

  async updateTransactionStatus(transactionId: number, status: string, txHash?: string): Promise<void> {
    const transaction = this.transactions.get(transactionId);
    if (transaction) {
      transaction.status = status;
      if (txHash) transaction.txHash = txHash;
      this.transactions.set(transactionId, transaction);
    }
  }
}

export const storage = new MemStorage();
