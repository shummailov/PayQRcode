import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertTransactionSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Serve test page
  app.get("/test", (req, res) => {
    res.sendFile("test.html", { root: "." });
  });
  // Get user profile
  app.get("/api/user/:id", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      // Don't return sensitive data like PIN
      const { pin, ...userWithoutPin } = user;
      res.json(userWithoutPin);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Verify PIN
  app.post("/api/auth/verify-pin", async (req, res) => {
    try {
      const { userId, pin, telegramId } = req.body;
      
      let user;
      if (telegramId) {
        // Try to find user by Telegram ID first
        user = await storage.getUserByTelegramId(telegramId);
        if (!user) {
          // Create new user for Telegram users
          user = await storage.createUser({
            username: `telegram_user_${telegramId}`,
            telegramId: telegramId,
            pin: pin
          });
          
          // Create initial wallets for new user
          await storage.createInitialWallets(user.id);
          
          return res.json({ success: true, userId: user.id, isNewUser: true });
        }
      } else if (userId) {
        user = await storage.getUser(userId);
      } else {
        // For demo purposes, create a demo user with any 4-digit PIN
        if (pin && pin.length === 4) {
          user = await storage.getUserByUsername("demo");
          if (!user) {
            user = await storage.createUser({
              username: "demo",
              telegramId: null,
              pin: pin
            });
            await storage.createInitialWallets(user.id);
          }
          return res.json({ success: true, userId: user.id });
        }
      }
      
      if (!user || user.pin !== pin) {
        return res.status(401).json({ message: "Invalid PIN" });
      }
      
      res.json({ success: true, userId: user.id });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Telegram auth route for demo users  
  app.post("/api/auth/telegram", async (req, res) => {
    try {
      const { telegramUser, pin } = req.body;
      
      if (!telegramUser || !pin) {
        return res.status(400).json({ error: "Telegram user data and PIN required" });
      }

      // Create or find Telegram user
      let user = await storage.getUserByTelegramId(telegramUser.id.toString());
      
      if (!user) {
        // Create new Telegram user
        user = await storage.createUser({
          username: telegramUser.username || `tg_${telegramUser.id}`,
          telegramId: telegramUser.id.toString(),
          pin: pin
        });
        
        // Create initial wallets for new user
        await storage.createInitialWallets(user.id);
      }

      res.json({ success: true, userId: user.id, telegramUser: true });
    } catch (error) {
      res.status(500).json({ error: "Telegram authentication failed" });
    }
  });

  // Get user wallets
  app.get("/api/wallets/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const wallets = await storage.getUserWallets(userId);
      res.json(wallets);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Get user transactions
  app.get("/api/transactions/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const transactions = await storage.getUserTransactions(userId);
      res.json(transactions);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Create transaction (send crypto)
  app.post("/api/transactions", async (req, res) => {
    try {
      const transactionData = insertTransactionSchema.parse(req.body);
      
      // Mock transaction creation - in real app, this would interact with blockchain
      const transaction = await storage.createTransaction({
        ...transactionData,
        status: "pending",
        txHash: `0x${Math.random().toString(16).substring(2, 66)}` // Mock transaction hash
      });

      // Simulate transaction confirmation after 3 seconds
      setTimeout(async () => {
        await storage.updateTransactionStatus(transaction.id, "confirmed");
        
        // Update wallet balances (mock calculation)
        if (transactionData.type === "send") {
          const userWallets = await storage.getUserWallets(transactionData.userId);
          const wallet = userWallets.find(w => w.currency === transactionData.currency);
          if (wallet) {
            const newBalance = (parseFloat(wallet.balance) - parseFloat(transactionData.amount)).toString();
            await storage.updateWalletBalance(wallet.id, newBalance);
          }
        }
      }, 3000);

      res.json(transaction);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid transaction data", errors: error.errors });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Get current crypto prices (mock data)
  app.get("/api/prices", async (req, res) => {
    try {
      // Mock crypto prices - in real app, this would fetch from crypto API
      const prices = {
        BTC: 34125.32,
        ETH: 1956.20,
        USDC: 1.00
      };
      res.json(prices);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Telegram webhook endpoint (for future use)
  app.post("/api/telegram/webhook", async (req, res) => {
    try {
      // Handle Telegram webhook updates
      const update = req.body;
      
      // Log webhook for debugging
      console.log("Telegram webhook received:", JSON.stringify(update, null, 2));
      
      res.json({ ok: true });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
