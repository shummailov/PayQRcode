import os
from telegram import InlineKeyboardButton, InlineKeyboardMarkup, WebAppInfo
from telegram.ext import ApplicationBuilder, CommandHandler, CallbackQueryHandler, ContextTypes

# Get bot token from environment variables
TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "7684847636:AAH93tlzw-o-HeJM_j1s6sUAAhiuewJ_VEo")

async def start(update: ContextTypes.DEFAULT_TYPE, context: ContextTypes.DEFAULT_TYPE):
    """Start command handler - shows main menu"""
    keyboard = [
        [InlineKeyboardButton("🚀 Open Wallet", web_app=WebAppInfo(url="https://workspace.antoinecarr.replit.app"))],
        [InlineKeyboardButton("🧪 Test Page", web_app=WebAppInfo(url="https://workspace.antoinecarr.replit.app/test"))],
        [InlineKeyboardButton("❓ How it works?", callback_data='how_it_works')],
        [InlineKeyboardButton("🔒 Refund & Security", callback_data='refund_security')],
        [InlineKeyboardButton("💬 Support", callback_data='support')],
        [InlineKeyboardButton("⚙️ Settings", callback_data='settings')],
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    welcome_message = """
🌟 Welcome to CryptoWallet!

Your secure multi-currency wallet for Bitcoin, Ethereum, and USDC.

✅ PIN-protected security
✅ Real-time balance tracking  
✅ Send & receive crypto
✅ Transaction history

Choose an option below to get started:
    """
    
    await update.message.reply_text(welcome_message, reply_markup=reply_markup)

async def button_handler(update: ContextTypes.DEFAULT_TYPE, context: ContextTypes.DEFAULT_TYPE):
    """Handle inline keyboard button presses"""
    query = update.callback_query
    await query.answer()

    if query.data == 'how_it_works':
        message = """
🔍 How CryptoWallet Works:

1️⃣ **Authentication**: Secure 4-digit PIN login
2️⃣ **Multi-Currency**: Support for BTC, ETH, and USDC
3️⃣ **Real-time Prices**: Live cryptocurrency price tracking
4️⃣ **Send & Receive**: Easy crypto transactions
5️⃣ **History**: Complete transaction records

Your wallet addresses are generated securely and your PIN never leaves your device.
        """
        
        back_keyboard = [[InlineKeyboardButton("← Back to Menu", callback_data='back_to_menu')]]
        reply_markup = InlineKeyboardMarkup(back_keyboard)
        
        await query.edit_message_text(message, reply_markup=reply_markup)
        
    elif query.data == 'refund_security':
        message = """
🔒 Security & Refund Information:

**Security Features:**
• PIN-based authentication
• Encrypted private key storage
• Secure transaction signing
• Real-time fraud detection

**Refund Policy:**
• Cryptocurrency transactions are irreversible
• Always verify recipient addresses
• Contact support for assistance
• Keep your PIN secure and private

**Emergency Contact:**
If you lose access to your wallet, contact support immediately.
        """
        
        back_keyboard = [[InlineKeyboardButton("← Back to Menu", callback_data='back_to_menu')]]
        reply_markup = InlineKeyboardMarkup(back_keyboard)
        
        await query.edit_message_text(message, reply_markup=reply_markup)
        
    elif query.data == 'support':
        message = """
💬 Support & Help:

**Contact Methods:**
📧 Email: support@cryptowallet.example.com
💬 Telegram: @CryptoWalletSupport
📞 Phone: +1 (555) 123-4567

**Support Hours:**
Monday - Friday: 9 AM - 6 PM EST
Weekend: 10 AM - 4 PM EST

**FAQ:**
• Forgot PIN? Contact support with your telegram ID
• Transaction stuck? Check network status
• Balance not updating? Refresh the app

We're here to help! 🤝
        """
        
        back_keyboard = [[InlineKeyboardButton("← Back to Menu", callback_data='back_to_menu')]]
        reply_markup = InlineKeyboardMarkup(back_keyboard)
        
        await query.edit_message_text(message, reply_markup=reply_markup)
        
    elif query.data == 'settings':
        message = """
⚙️ Wallet Settings:

**Account Information:**
👤 Telegram ID: {user_id}
🕒 Joined: Today
📱 App Version: 1.0.0

**Security Settings:**
🔐 PIN Protection: Enabled
🔔 Notifications: Enabled
🌐 Language: English

**Quick Actions:**
• Change PIN (via web app)
• Export transaction history
• Enable/disable notifications

Use the web app for advanced settings.
        """.format(user_id=query.from_user.id)
        
        back_keyboard = [[InlineKeyboardButton("← Back to Menu", callback_data='back_to_menu')]]
        reply_markup = InlineKeyboardMarkup(back_keyboard)
        
        await query.edit_message_text(message, reply_markup=reply_markup)
        
    elif query.data == 'back_to_menu':
        # Show the main menu again
        keyboard = [
            [InlineKeyboardButton("🚀 Open Wallet", web_app=WebAppInfo(url="https://workspace.antoinecarr.replit.app"))],
            [InlineKeyboardButton("❓ How it works?", callback_data='how_it_works')],
            [InlineKeyboardButton("🔒 Refund & Security", callback_data='refund_security')],
            [InlineKeyboardButton("💬 Support", callback_data='support')],
            [InlineKeyboardButton("⚙️ Settings", callback_data='settings')],
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        welcome_message = """
🌟 Welcome to CryptoWallet!

Your secure multi-currency wallet for Bitcoin, Ethereum, and USDC.

✅ PIN-protected security
✅ Real-time balance tracking  
✅ Send & receive crypto
✅ Transaction history

Choose an option below to get started:
        """
        
        await query.edit_message_text(welcome_message, reply_markup=reply_markup)
        
    else:
        await query.edit_message_text("❌ Unknown command. Please try again.")

async def help_command(update: ContextTypes.DEFAULT_TYPE, context: ContextTypes.DEFAULT_TYPE):
    """Help command handler"""
    help_text = """
🆘 CryptoWallet Help:

**Available Commands:**
/start - Open main menu
/help - Show this help message
/balance - Quick balance check (coming soon)
/support - Contact support

**Getting Started:**
1. Use /start to open the main menu
2. Click "Open Wallet" to access your crypto wallet
3. Set up your 4-digit PIN for security
4. Start sending and receiving cryptocurrency!

**Need Help?**
Use the Support option in the main menu or contact us directly.
    """
    
    await update.message.reply_text(help_text)

def main():
    """Start the Telegram bot"""
    if TOKEN == "YOUR_BOT_TOKEN_HERE":
        print("⚠️  Please set your TELEGRAM_BOT_TOKEN environment variable!")
        print("   1. Get a bot token from @BotFather on Telegram")
        print("   2. Set the environment variable: TELEGRAM_BOT_TOKEN=your_token_here")
        print("   3. Update the web app URL in the code")
        return
    
    print("🤖 Starting CryptoWallet Telegram Bot...")
    
    # Create the application
    app = ApplicationBuilder().token(TOKEN).build()
    
    # Add command handlers
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_command))
    
    # Add callback query handler for inline keyboards
    app.add_handler(CallbackQueryHandler(button_handler))
    
    # Start the bot
    print("✅ Bot is running! Send /start to interact with it.")
    app.run_polling()

if __name__ == '__main__':
    main()