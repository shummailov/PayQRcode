import React, { useState, useEffect } from "react";
import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Wallet from "@/pages/wallet";
import TelegramDebug from "@/components/telegram-debug";
import TelegramTest from "@/components/telegram-test";
import TelegramMiniApp from "@/components/telegram-mini-app";

function Router() {
  // Show simple mini app interface if in Telegram and not loaded
  const tg = (window as any).Telegram?.WebApp;
  const isLoaded = window.location.search.includes('loaded=true');
  
  if (tg && !isLoaded) {
    return <TelegramMiniApp />;
  }

  return (
    <Switch>
      <Route path="/" component={Wallet} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Add Telegram-specific class to body
    const tg = (window as any).Telegram?.WebApp;
    if (tg) {
      document.body.classList.add('telegram-webapp');
      
      // Force the webapp to be visible
      document.documentElement.style.height = '100%';
      document.body.style.height = '100%';
      document.body.style.margin = '0';
      document.body.style.padding = '0';
      document.body.style.overflow = 'hidden';
      
      const root = document.getElementById('root');
      if (root) {
        root.style.height = '100%';
        root.style.minHeight = '100vh';
        root.style.display = 'block';
        root.style.visibility = 'visible';
      }
    }

    // Set loading to false after a brief moment to show the app
    const timer = setTimeout(() => setIsLoading(false), 500); // Reduced to make it faster
    return () => clearTimeout(timer);
  }, []);

  if (isLoading) {
    return (
      <div className="min-h-screen h-screen bg-gradient-to-br from-blue-900 to-purple-900 flex items-center justify-center" style={{ 
        height: '100vh',
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        width: '100%',
        zIndex: 10000
      }}>
        <div className="text-center p-8">
          <div className="w-20 h-20 border-4 border-white border-t-transparent rounded-full animate-spin mx-auto mb-6"></div>
          <h1 className="text-white text-3xl font-bold mb-2">CryptoWallet</h1>
          <p className="text-blue-200 text-lg mb-4">Loading your secure wallet...</p>
          <div className="bg-white/10 backdrop-blur rounded-lg p-4 mb-4">
            <p className="text-blue-300 text-sm">
              {typeof window !== 'undefined' && (window as any).Telegram?.WebApp ? 'Running in Telegram' : 'Web Browser'}
            </p>
          </div>
          <div className="text-xs text-blue-400">
            Enter PIN: 1234 (Demo)
          </div>
        </div>
      </div>
    );
  }

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <div className="min-h-screen h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900" style={{ 
          minHeight: '100vh', 
          height: '100vh',
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          width: '100%'
        }}>
          <TelegramDebug />
          <Toaster />
          <Router />
        </div>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
