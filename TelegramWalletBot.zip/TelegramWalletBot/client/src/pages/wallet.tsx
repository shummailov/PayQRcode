import { useState } from "react";
import AuthScreen from "@/components/auth-screen";
import WalletBalance from "@/components/wallet-balance";
import AssetsList from "@/components/assets-list";
import TransactionHistory from "@/components/transaction-history";
import SendModal from "@/components/send-modal";
import ReceiveModal from "@/components/receive-modal";
import BottomNavigation from "@/components/bottom-navigation";
import { Settings } from "lucide-react";

export default function Wallet() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [showSendModal, setShowSendModal] = useState(false);
  const [showReceiveModal, setShowReceiveModal] = useState(false);
  const [activeTab, setActiveTab] = useState("wallet");

  // Get current user from session storage or Telegram WebApp
  const getCurrentUser = () => {
    const tg = (window as any).Telegram?.WebApp;
    const telegramUser = tg?.initDataUnsafe?.user;
    
    if (telegramUser) {
      return {
        id: parseInt(sessionStorage.getItem("userId") || "1"),
        username: telegramUser.username || `telegram_user_${telegramUser.id}`
      };
    }
    
    return { id: 1, username: "demo_user" };
  };
  
  const currentUser = getCurrentUser();

  if (!isAuthenticated) {
    return <AuthScreen onAuthenticated={() => setIsAuthenticated(true)} />;
  }

  return (
    <div className="max-w-md mx-auto min-h-screen relative">
      {/* Header */}
      <header className="flex items-center justify-between p-4 glass-morphism">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 crypto-gradient rounded-full flex items-center justify-center">
            <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z" />
            </svg>
          </div>
          <div>
            <h1 className="text-lg font-bold text-slate-100">CryptoWallet</h1>
            <p className="text-xs text-slate-400">@{currentUser.username}</p>
          </div>
        </div>
        <button className="p-2 rounded-lg bg-slate-700 hover:bg-slate-600 transition-colors">
          <Settings className="w-5 h-5 text-slate-300" />
        </button>
      </header>

      {/* Main Content */}
      <div className="pb-20">
        {activeTab === "wallet" && (
          <>
            <WalletBalance 
              userId={currentUser.id}
              onSend={() => setShowSendModal(true)}
              onReceive={() => setShowReceiveModal(true)}
            />
            <AssetsList userId={currentUser.id} />
            <TransactionHistory userId={currentUser.id} />
          </>
        )}
        
        {activeTab === "market" && (
          <div className="p-6 text-center text-slate-400">
            <h2 className="text-xl font-bold mb-2">Market</h2>
            <p>Market data coming soon...</p>
          </div>
        )}
        
        {activeTab === "history" && (
          <div className="mx-4">
            <h2 className="text-xl font-bold text-slate-100 mb-4 px-2">All Transactions</h2>
            <TransactionHistory userId={currentUser.id} showAll={true} />
          </div>
        )}
        
        {activeTab === "settings" && (
          <div className="p-6 text-center text-slate-400">
            <h2 className="text-xl font-bold mb-2">Settings</h2>
            <p>Settings panel coming soon...</p>
          </div>
        )}
      </div>

      {/* Modals */}
      {showSendModal && (
        <SendModal 
          userId={currentUser.id}
          onClose={() => setShowSendModal(false)} 
        />
      )}
      
      {showReceiveModal && (
        <ReceiveModal onClose={() => setShowReceiveModal(false)} />
      )}

      {/* Bottom Navigation */}
      <BottomNavigation activeTab={activeTab} onTabChange={setActiveTab} />
    </div>
  );
}
