import { useEffect, useState } from "react";

export default function TelegramDebug() {
  const [debugInfo, setDebugInfo] = useState<any>({});

  useEffect(() => {
    const tg = (window as any).Telegram?.WebApp;
    if (tg) {
      setDebugInfo({
        isAvailable: true,
        platform: tg.platform,
        version: tg.version,
        colorScheme: tg.colorScheme,
        themeParams: tg.themeParams,
        initData: tg.initData,
        initDataUnsafe: tg.initDataUnsafe,
        isExpanded: tg.isExpanded,
        viewportHeight: tg.viewportHeight,
        viewportStableHeight: tg.viewportStableHeight,
      });
    } else {
      setDebugInfo({ isAvailable: false });
    }
  }, []);

  // Always show in development, hide after 10 seconds
  if (process.env.NODE_ENV === 'production') {
    return null;
  }

  return (
    <div className="fixed top-0 left-0 right-0 bg-green-900 text-white text-xs p-2 z-50 overflow-auto max-h-40">
      <strong>Telegram Debug:</strong> {debugInfo.isAvailable ? '✅ Connected' : '❌ Not in Telegram'}
      <div className="mt-1">
        Viewport: {debugInfo.viewportHeight}px | 
        Expanded: {debugInfo.isExpanded ? 'Yes' : 'No'} | 
        Version: {debugInfo.version}
      </div>
    </div>
  );
}