import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

interface AssetsListProps {
  userId: number;
}

export default function AssetsList({ userId }: AssetsListProps) {
  const { data: wallets, isLoading: walletsLoading } = useQuery({
    queryKey: ["/api/wallets", userId],
  });

  const { data: prices, isLoading: pricesLoading } = useQuery({
    queryKey: ["/api/prices"],
  });

  const isLoading = walletsLoading || pricesLoading;

  const getCurrencyIcon = (currency: string) => {
    const icons = {
      BTC: { bg: "bg-orange-500", symbol: "₿" },
      ETH: { bg: "bg-purple-500", symbol: "Ξ" },
      USDC: { bg: "bg-blue-500", symbol: "USDC" }
    };
    return icons[currency as keyof typeof icons] || { bg: "bg-gray-500", symbol: currency };
  };

  const getCurrencyName = (currency: string) => {
    const names = {
      BTC: "Bitcoin",
      ETH: "Ethereum", 
      USDC: "USD Coin"
    };
    return names[currency as keyof typeof names] || currency;
  };

  if (isLoading) {
    return (
      <section className="mx-4 mb-6">
        <h3 className="text-lg font-semibold text-slate-100 mb-4 px-2">Assets</h3>
        <Card className="bg-slate-800 border-slate-700">
          {[1, 2, 3].map(i => (
            <div key={i} className="flex items-center justify-between p-4 border-b border-slate-700 last:border-b-0">
              <div className="flex items-center space-x-3">
                <Skeleton className="w-10 h-10 rounded-full" />
                <div>
                  <Skeleton className="h-4 w-16 mb-1" />
                  <Skeleton className="h-3 w-8" />
                </div>
              </div>
              <div className="text-right">
                <Skeleton className="h-4 w-20 mb-1" />
                <Skeleton className="h-3 w-16" />
              </div>
            </div>
          ))}
        </Card>
      </section>
    );
  }

  return (
    <section className="mx-4 mb-6">
      <h3 className="text-lg font-semibold text-slate-100 mb-4 px-2">Assets</h3>
      <Card className="bg-slate-800 border-slate-700 overflow-hidden">
        {wallets?.map((wallet: any) => {
          const icon = getCurrencyIcon(wallet.currency);
          const price = prices?.[wallet.currency] || 0;
          const balance = parseFloat(wallet.balance) || 0;
          const usdValue = balance * price;

          return (
            <div 
              key={wallet.id}
              className="flex items-center justify-between p-4 border-b border-slate-700 last:border-b-0 hover:bg-slate-700/50 transition-colors cursor-pointer"
            >
              <div className="flex items-center space-x-3">
                <div className={`w-10 h-10 ${icon.bg} rounded-full flex items-center justify-center`}>
                  <span className="text-white font-bold text-sm">{icon.symbol}</span>
                </div>
                <div>
                  <p className="font-semibold text-slate-100">{getCurrencyName(wallet.currency)}</p>
                  <p className="text-sm text-slate-400">{wallet.currency}</p>
                </div>
              </div>
              <div className="text-right">
                <p className="font-semibold text-slate-100">
                  {balance.toFixed(4)} {wallet.currency}
                </p>
                <p className="text-sm text-slate-400">
                  ${usdValue.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </p>
              </div>
            </div>
          );
        })}
      </Card>
    </section>
  );
}
