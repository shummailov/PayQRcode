import { useEffect, useState } from "react";

export default function TelegramMiniApp() {
  const [status, setStatus] = useState("Initializing...");

  useEffect(() => {
    const tg = (window as any).Telegram?.WebApp;
    
    if (tg) {
      setStatus("Telegram WebApp detected! Starting wallet...");
      
      // Try to make the content as visible as possible
      setTimeout(() => {
        setStatus("Wallet is ready! Please enter PIN: 1234");
      }, 1000);
    } else {
      setStatus("Running in web browser");
    }
  }, []);

  return (
    <div style={{
      position: 'fixed',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      width: '100vw',
      height: '100vh',
      backgroundColor: '#1e40af',
      color: 'white',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '20px',
      zIndex: 99999,
      fontFamily: 'Arial, sans-serif'
    }}>
      <div style={{
        textAlign: 'center',
        maxWidth: '300px'
      }}>
        <h1 style={{
          fontSize: '24px',
          marginBottom: '20px',
          fontWeight: 'bold'
        }}>
          🚀 CryptoWallet
        </h1>
        
        <div style={{
          backgroundColor: 'rgba(255,255,255,0.1)',
          padding: '20px',
          borderRadius: '10px',
          marginBottom: '20px'
        }}>
          <p style={{
            fontSize: '16px',
            lineHeight: '1.5',
            margin: 0
          }}>
            {status}
          </p>
        </div>

        <div style={{
          backgroundColor: 'rgba(255,255,255,0.1)',
          padding: '15px',
          borderRadius: '8px',
          fontSize: '14px'
        }}>
          <p style={{ margin: 0 }}>
            Demo PIN: <strong>1234</strong>
          </p>
        </div>

        <button 
          style={{
            marginTop: '20px',
            backgroundColor: '#3b82f6',
            color: 'white',
            border: 'none',
            padding: '12px 24px',
            borderRadius: '8px',
            fontSize: '16px',
            cursor: 'pointer'
          }}
          onClick={() => {
            window.location.href = window.location.href + '?loaded=true';
          }}
        >
          Continue to Wallet
        </button>
      </div>
    </div>
  );
}