import { useEffect, useState } from "react";

export default function TelegramTest() {
  const [status, setStatus] = useState("Initializing...");
  const [tgData, setTgData] = useState<any>(null);

  useEffect(() => {
    const tg = (window as any).Telegram?.WebApp;
    
    if (tg) {
      setStatus("✅ Telegram WebApp Connected");
      setTgData({
        version: tg.version,
        platform: tg.platform,
        viewportHeight: tg.viewportHeight,
        isExpanded: tg.isExpanded,
        colorScheme: tg.colorScheme,
        user: tg.initDataUnsafe?.user,
        initData: tg.initData ? "Present" : "None"
      });
    } else {
      setStatus("❌ Not in Telegram WebApp");
    }
  }, []);

  return (
    <div className="min-h-screen bg-blue-900 text-white p-6 flex flex-col items-center justify-center">
      <div className="max-w-md w-full bg-blue-800 rounded-lg p-6 text-center">
        <h1 className="text-2xl font-bold mb-4">🚀 CryptoWallet Test</h1>
        
        <div className="bg-blue-700 rounded p-4 mb-4">
          <h2 className="font-semibold mb-2">Status:</h2>
          <p className="text-blue-200">{status}</p>
        </div>

        {tgData && (
          <div className="bg-blue-700 rounded p-4 mb-4 text-left">
            <h3 className="font-semibold mb-2">Telegram Data:</h3>
            <div className="text-sm space-y-1">
              <p>Version: {tgData.version}</p>
              <p>Platform: {tgData.platform}</p>
              <p>Viewport: {tgData.viewportHeight}px</p>
              <p>Expanded: {tgData.isExpanded ? 'Yes' : 'No'}</p>
              <p>Theme: {tgData.colorScheme}</p>
              <p>InitData: {tgData.initData}</p>
              {tgData.user && (
                <p>User: {tgData.user.first_name} ({tgData.user.id})</p>
              )}
            </div>
          </div>
        )}

        <button 
          className="bg-blue-600 hover:bg-blue-500 px-6 py-3 rounded font-semibold"
          onClick={() => window.location.reload()}
        >
          Reload Test
        </button>
      </div>
    </div>
  );
}