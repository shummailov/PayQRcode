import { Button } from "@/components/ui/button";
import { Wallet, TrendingUp, Clock, User } from "lucide-react";

interface BottomNavigationProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

export default function BottomNavigation({ activeTab, onTabChange }: BottomNavigationProps) {
  const tabs = [
    { id: "wallet", label: "Wallet", icon: Wallet },
    { id: "market", label: "Market", icon: TrendingUp },
    { id: "history", label: "History", icon: Clock },
    { id: "settings", label: "Profile", icon: User },
  ];

  return (
    <nav className="fixed bottom-0 left-1/2 transform -translate-x-1/2 w-full max-w-md glass-morphism border-t border-slate-700">
      <div className="flex items-center justify-around py-2">
        {tabs.map(({ id, label, icon: Icon }) => (
          <Button
            key={id}
            variant="ghost"
            className={`flex flex-col items-center p-3 transition-colors ${
              activeTab === id 
                ? "text-blue-500" 
                : "text-slate-400 hover:text-slate-300"
            }`}
            onClick={() => onTabChange(id)}
          >
            <Icon className="w-6 h-6 mb-1" />
            <span className="text-xs font-medium">{label}</span>
          </Button>
        ))}
      </div>
    </nav>
  );
}
