import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { UserPlus, Send, ArrowUpDown } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

interface TransactionHistoryProps {
  userId: number;
  showAll?: boolean;
}

export default function TransactionHistory({ userId, showAll = false }: TransactionHistoryProps) {
  const { data: transactions, isLoading } = useQuery({
    queryKey: ["/api/transactions", userId],
  });

  const getTransactionIcon = (type: string) => {
    switch (type) {
      case "receive":
        return { icon: UserPlus, color: "bg-green-600" };
      case "send":
        return { icon: Send, color: "bg-red-600" };
      case "swap":
        return { icon: ArrowUpDown, color: "bg-yellow-600" };
      default:
        return { icon: Send, color: "bg-gray-600" };
    }
  };

  const getTransactionTitle = (transaction: any) => {
    switch (transaction.type) {
      case "receive":
        return `Received ${transaction.currency}`;
      case "send":
        return `Sent ${transaction.currency}`;
      case "swap":
        return `Swapped ${transaction.currency}`;
      default:
        return "Transaction";
    }
  };

  const displayTransactions = showAll ? transactions : transactions?.slice(0, 3);

  if (isLoading) {
    return (
      <section className="mx-4 mb-6">
        <div className="flex items-center justify-between mb-4 px-2">
          <h3 className="text-lg font-semibold text-slate-100">Recent Transactions</h3>
          {!showAll && <Skeleton className="h-4 w-16" />}
        </div>
        <Card className="bg-slate-800 border-slate-700">
          {[1, 2, 3].map(i => (
            <div key={i} className="flex items-center justify-between p-4 border-b border-slate-700 last:border-b-0">
              <div className="flex items-center space-x-3">
                <Skeleton className="w-10 h-10 rounded-full" />
                <div>
                  <Skeleton className="h-4 w-24 mb-1" />
                  <Skeleton className="h-3 w-16" />
                </div>
              </div>
              <div className="text-right">
                <Skeleton className="h-4 w-20 mb-1" />
                <Skeleton className="h-3 w-16" />
              </div>
            </div>
          ))}
        </Card>
      </section>
    );
  }

  return (
    <section className="mx-4 mb-6">
      <div className="flex items-center justify-between mb-4 px-2">
        <h3 className="text-lg font-semibold text-slate-100">
          {showAll ? "All Transactions" : "Recent Transactions"}
        </h3>
        {!showAll && (
          <Button variant="link" className="text-blue-500 text-sm font-medium hover:text-blue-400 p-0">
            View All
          </Button>
        )}
      </div>
      
      <Card className="bg-slate-800 border-slate-700 overflow-hidden">
        {displayTransactions?.length === 0 ? (
          <div className="p-8 text-center text-slate-400">
            <p>No transactions yet</p>
          </div>
        ) : (
          displayTransactions?.map((transaction: any) => {
            const { icon: Icon, color } = getTransactionIcon(transaction.type);
            const isPositive = transaction.type === "receive";
            const amount = parseFloat(transaction.amount);

            return (
              <div 
                key={transaction.id}
                className="flex items-center justify-between p-4 border-b border-slate-700 last:border-b-0"
              >
                <div className="flex items-center space-x-3">
                  <div className={`w-10 h-10 ${color} rounded-full flex items-center justify-center`}>
                    <Icon className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <p className="font-semibold text-slate-100">{getTransactionTitle(transaction)}</p>
                    <p className="text-sm text-slate-400">
                      {formatDistanceToNow(new Date(transaction.createdAt), { addSuffix: true })}
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <p className={`font-semibold ${isPositive ? "text-green-400" : "text-red-400"}`}>
                    {isPositive ? "+" : "-"}{amount.toFixed(4)} {transaction.currency}
                  </p>
                  <p className="text-sm text-slate-400">
                    {transaction.status === "confirmed" ? "Confirmed" : "Pending"}
                  </p>
                </div>
              </div>
            );
          })
        )}
      </Card>
    </section>
  );
}
