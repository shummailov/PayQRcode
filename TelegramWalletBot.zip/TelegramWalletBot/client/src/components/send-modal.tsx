import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { X, QrCode, ChevronDown } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface SendModalProps {
  userId: number;
  onClose: () => void;
}

export default function SendModal({ userId, onClose }: SendModalProps) {
  const [selectedWallet, setSelectedWallet] = useState<any>(null);
  const [recipientAddress, setRecipientAddress] = useState("");
  const [amount, setAmount] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: wallets } = useQuery({
    queryKey: ["/api/wallets", userId],
  });

  const { data: prices } = useQuery({
    queryKey: ["/api/prices"],
  });

  const sendTransaction = useMutation({
    mutationFn: async (transactionData: any) => {
      const response = await apiRequest("POST", "/api/transactions", transactionData);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Transaction Sent",
        description: "Your transaction has been submitted to the network."
      });
      queryClient.invalidateQueries({ queryKey: ["/api/wallets", userId] });
      queryClient.invalidateQueries({ queryKey: ["/api/transactions", userId] });
      onClose();
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Transaction Failed",
        description: "Please try again later."
      });
    }
  });

  const getCurrencyIcon = (currency: string) => {
    const icons = {
      BTC: { bg: "bg-orange-500", symbol: "₿" },
      ETH: { bg: "bg-purple-500", symbol: "Ξ" },
      USDC: { bg: "bg-blue-500", symbol: "USDC" }
    };
    return icons[currency as keyof typeof icons] || { bg: "bg-gray-500", symbol: currency };
  };

  const getCurrencyName = (currency: string) => {
    const names = {
      BTC: "Bitcoin",
      ETH: "Ethereum", 
      USDC: "USD Coin"
    };
    return names[currency as keyof typeof names] || currency;
  };

  const calculateUsdValue = () => {
    if (!selectedWallet || !amount || !prices) return 0;
    const price = prices[selectedWallet.currency] || 0;
    return parseFloat(amount) * price;
  };

  const handlePercentageClick = (percentage: number) => {
    if (!selectedWallet) return;
    const balance = parseFloat(selectedWallet.balance);
    const newAmount = (balance * percentage / 100).toString();
    setAmount(newAmount);
  };

  const handleSend = () => {
    if (!selectedWallet || !recipientAddress || !amount) {
      toast({
        variant: "destructive",
        title: "Missing Information",
        description: "Please fill in all required fields."
      });
      return;
    }

    const amountNum = parseFloat(amount);
    const balanceNum = parseFloat(selectedWallet.balance);

    if (amountNum <= 0 || amountNum > balanceNum) {
      toast({
        variant: "destructive",
        title: "Invalid Amount",
        description: "Please enter a valid amount within your balance."
      });
      return;
    }

    sendTransaction.mutate({
      userId,
      fromAddress: selectedWallet.address,
      toAddress: recipientAddress,
      amount,
      currency: selectedWallet.currency,
      type: "send",
      networkFee: "0.002" // Mock network fee
    });
  };

  // Auto-select first wallet if available
  if (wallets && wallets.length > 0 && !selectedWallet) {
    setSelectedWallet(wallets[0]);
  }

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-40 flex items-end">
      <Card className="bg-slate-800 border-slate-700 rounded-t-3xl w-full max-h-[80vh] overflow-y-auto">
        <div className="flex items-center justify-between p-6 border-b border-slate-700">
          <h3 className="text-xl font-bold text-slate-100">Send Crypto</h3>
          <Button 
            variant="ghost" 
            size="icon"
            onClick={onClose}
            className="text-slate-400 hover:text-slate-100"
          >
            <X className="w-6 h-6" />
          </Button>
        </div>
        
        <div className="p-6 space-y-6">
          {/* Asset Selection */}
          <div>
            <Label className="text-sm font-medium text-slate-300 mb-3">Select Asset</Label>
            {selectedWallet && (
              <div className="bg-slate-700 rounded-xl p-4 flex items-center justify-between cursor-pointer hover:bg-slate-600 transition-colors">
                <div className="flex items-center space-x-3">
                  {(() => {
                    const icon = getCurrencyIcon(selectedWallet.currency);
                    return (
                      <div className={`w-8 h-8 ${icon.bg} rounded-full flex items-center justify-center`}>
                        <span className="text-white font-bold text-xs">{icon.symbol}</span>
                      </div>
                    );
                  })()}
                  <div>
                    <p className="font-semibold text-slate-100">{getCurrencyName(selectedWallet.currency)}</p>
                    <p className="text-sm text-slate-400">Balance: {parseFloat(selectedWallet.balance).toFixed(4)} {selectedWallet.currency}</p>
                  </div>
                </div>
                <ChevronDown className="w-5 h-5 text-slate-400" />
              </div>
            )}
          </div>

          {/* Recipient Address */}
          <div>
            <Label className="text-sm font-medium text-slate-300 mb-3">Recipient Address</Label>
            <div className="relative">
              <Input 
                type="text" 
                className="bg-slate-700 border-slate-600 text-slate-100 placeholder-slate-400 pr-12"
                placeholder="Enter wallet address or scan QR"
                value={recipientAddress}
                onChange={(e) => setRecipientAddress(e.target.value)}
              />
              <Button
                variant="ghost"
                size="icon"
                className="absolute right-2 top-1/2 transform -translate-y-1/2 text-slate-400 hover:text-slate-100"
              >
                <QrCode className="w-5 h-5" />
              </Button>
            </div>
          </div>

          {/* Amount */}
          <div>
            <Label className="text-sm font-medium text-slate-300 mb-3">Amount</Label>
            <div className="bg-slate-700 rounded-xl p-4">
              <div className="flex items-center justify-between mb-2">
                <Input
                  type="number"
                  className="bg-transparent text-2xl font-bold text-slate-100 placeholder-slate-400 border-0 p-0 h-auto"
                  placeholder="0.00"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                />
                <span className="text-slate-400 font-medium">{selectedWallet?.currency}</span>
              </div>
              <p className="text-slate-400 text-sm">≈ ${calculateUsdValue().toFixed(2)} USD</p>
              <div className="flex space-x-2 mt-3">
                {[25, 50, 75, 100].map(percentage => (
                  <Button
                    key={percentage}
                    variant="ghost"
                    size="sm"
                    className="bg-slate-600 hover:bg-slate-500 text-slate-300"
                    onClick={() => handlePercentageClick(percentage)}
                  >
                    {percentage === 100 ? "Max" : `${percentage}%`}
                  </Button>
                ))}
              </div>
            </div>
          </div>

          {/* Network Fee */}
          <div className="bg-slate-700/50 rounded-xl p-4">
            <div className="flex items-center justify-between">
              <span className="text-slate-300">Network Fee</span>
              <span className="text-slate-100 font-medium">~$2.45</span>
            </div>
            <p className="text-slate-400 text-sm mt-1">Estimated confirmation time: 10-30 min</p>
          </div>

          {/* Send Button */}
          <Button 
            className="w-full crypto-gradient text-white font-semibold py-4 hover:opacity-90 transition-opacity"
            onClick={handleSend}
            disabled={sendTransaction.isPending}
          >
            {sendTransaction.isPending ? "Sending..." : "Review Transaction"}
          </Button>
        </div>
      </Card>
    </div>
  );
}
