import { useState } from "react";
import { Lock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface AuthScreenProps {
  onAuthenticated: () => void;
}

export default function AuthScreen({ onAuthenticated }: AuthScreenProps) {
  const [pin, setPin] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handlePinInput = (digit: string) => {
    if (pin.length < 4) {
      setPin(prev => prev + digit);
    }
  };

  const handleBackspace = () => {
    setPin(prev => prev.slice(0, -1));
  };

  const handleSubmit = async () => {
    if (pin.length === 4) {
      setIsLoading(true);
      try {
        // Check if running in Telegram WebApp
        const tg = (window as any).Telegram?.WebApp;
        const telegramUser = tg?.initDataUnsafe?.user;
        
        console.log('Auth attempt:', { 
          isTelegram: !!tg, 
          hasUser: !!telegramUser,
          userId: telegramUser?.id,
          initData: tg?.initData ? 'Present' : 'None'
        });

        // If in Telegram but no user data, create a demo Telegram user
        if (tg && !telegramUser && pin === "1234") {
          console.log('Creating demo Telegram user for testing');
          const demoTelegramUser = {
            id: 999999999,
            first_name: "Telegram",
            last_name: "User",
            username: "telegram_demo"
          };
          
          try {
            const createResponse = await apiRequest("/api/auth/telegram", {
              method: "POST",
              body: JSON.stringify({
                telegramUser: demoTelegramUser,
                pin: pin
              })
            });
            
            if (createResponse.ok) {
              const result = await createResponse.json();
              onAuthenticated();
              return;
            }
          } catch (error) {
            console.log('Demo Telegram user creation failed, trying regular auth');
          }
        }
        
        const authData: any = { pin };
        
        if (telegramUser?.id) {
          authData.telegramId = telegramUser.id.toString();
        } else {
          authData.userId = 1; // Demo user ID for non-Telegram usage
        }
        
        const response = await apiRequest("POST", "/api/auth/verify-pin", authData);
        const result = await response.json();
        
        // Store user ID for later use
        if (result.userId) {
          sessionStorage.setItem("userId", result.userId.toString());
        }
        
        onAuthenticated();
      } catch (error) {
        toast({
          variant: "destructive",
          title: "Invalid PIN",
          description: "Please try again."
        });
        setPin("");
      } finally {
        setIsLoading(false);
      }
    }
  };

  // Auto-submit when PIN is complete
  if (pin.length === 4 && !isLoading) {
    handleSubmit();
  }

  const pinNumbers = [
    "1", "2", "3",
    "4", "5", "6", 
    "7", "8", "9",
    "", "0", "⌫"
  ];

  return (
    <div className="fixed inset-0 bg-slate-900 z-50 flex items-center justify-center p-4">
      <div className="bg-slate-800 rounded-2xl p-8 w-full max-w-sm shadow-2xl border border-slate-700">
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
            <Lock className="w-8 h-8 text-white" />
          </div>
          <h2 className="text-2xl font-bold text-white mb-2">Enter PIN</h2>
          <p className="text-slate-400">Secure access to your wallet</p>
        </div>
        
        <div className="flex justify-center space-x-4 mb-8">
          {[0, 1, 2, 3].map(index => (
            <div 
              key={index}
              className={`w-4 h-4 rounded-full border-2 transition-colors ${
                index < pin.length 
                  ? "border-blue-600 bg-blue-600" 
                  : "border-slate-600"
              }`}
            />
          ))}
        </div>
        
        <div className="grid grid-cols-3 gap-4 text-center">
          {pinNumbers.map((number, index) => (
            <Button
              key={index}
              variant="ghost"
              className={`h-16 rounded-xl bg-slate-700 hover:bg-slate-600 text-xl font-semibold transition-colors text-slate-100 ${
                number === "" ? "invisible" : ""
              }`}
              onClick={() => {
                if (number === "⌫") {
                  handleBackspace();
                } else if (number !== "") {
                  handlePinInput(number);
                }
              }}
              disabled={isLoading}
            >
              {number}
            </Button>
          ))}
        </div>
      </div>
    </div>
  );
}
