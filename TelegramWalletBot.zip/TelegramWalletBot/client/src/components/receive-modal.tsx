import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { X, Copy, Share } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface ReceiveModalProps {
  onClose: () => void;
}

export default function ReceiveModal({ onClose }: ReceiveModalProps) {
  const [selectedCurrency] = useState("BTC");
  const { toast } = useToast();
  
  // Mock wallet address
  const walletAddress = "bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh";

  const handleCopyAddress = async () => {
    try {
      await navigator.clipboard.writeText(walletAddress);
      toast({
        title: "Address Copied",
        description: "Wallet address has been copied to clipboard."
      });
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Copy Failed",
        description: "Unable to copy address to clipboard."
      });
    }
  };

  const handleShareAddress = () => {
    if (navigator.share) {
      navigator.share({
        title: "My Wallet Address",
        text: `Send ${selectedCurrency} to this address: ${walletAddress}`
      });
    } else {
      toast({
        title: "Share",
        description: "Share functionality not available on this device."
      });
    }
  };

  // Simple QR code pattern for demo
  const QRPattern = () => (
    <div className="w-48 h-48 bg-gray-100 rounded-xl flex items-center justify-center">
      <div className="grid grid-cols-8 gap-1">
        {Array.from({ length: 64 }, (_, i) => (
          <div
            key={i}
            className={`w-2 h-2 ${Math.random() > 0.5 ? "bg-black" : ""}`}
          />
        ))}
      </div>
    </div>
  );

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-40 flex items-end">
      <Card className="bg-slate-800 border-slate-700 rounded-t-3xl w-full max-h-[80vh] overflow-y-auto">
        <div className="flex items-center justify-between p-6 border-b border-slate-700">
          <h3 className="text-xl font-bold text-slate-100">Receive Crypto</h3>
          <Button 
            variant="ghost" 
            size="icon"
            onClick={onClose}
            className="text-slate-400 hover:text-slate-100"
          >
            <X className="w-6 h-6" />
          </Button>
        </div>
        
        <div className="p-6 text-center">
          {/* QR Code */}
          <div className="bg-white rounded-2xl p-6 inline-block mb-6">
            <QRPattern />
          </div>

          {/* Wallet Address */}
          <div className="bg-slate-700 rounded-xl p-4 mb-6">
            <p className="text-slate-300 text-sm mb-2">Bitcoin Address</p>
            <p className="text-slate-100 font-mono text-sm break-all">{walletAddress}</p>
          </div>

          {/* Action Buttons */}
          <div className="flex space-x-3 mb-6">
            <Button
              onClick={handleCopyAddress}
              className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3"
            >
              <Copy className="w-5 h-5 mr-2" />
              Copy
            </Button>
            <Button
              onClick={handleShareAddress}
              variant="outline"
              className="flex-1 bg-slate-700 hover:bg-slate-600 text-slate-100 border-slate-600 font-semibold py-3"
            >
              <Share className="w-5 h-5 mr-2" />
              Share
            </Button>
          </div>

          {/* Security Notice */}
          <div className="bg-amber-500/10 border border-amber-500/20 rounded-xl p-4">
            <div className="flex items-start space-x-3">
              <svg className="w-5 h-5 text-amber-500 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.732-.833-2.5 0L4.768 15.5c-.77.833.192 2.5 1.732 2.5z" />
              </svg>
              <div className="text-left">
                <p className="text-amber-200 text-sm font-medium">Security Notice</p>
                <p className="text-amber-200/80 text-sm">Only send Bitcoin to this address. Sending other cryptocurrencies may result in permanent loss.</p>
              </div>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
}
