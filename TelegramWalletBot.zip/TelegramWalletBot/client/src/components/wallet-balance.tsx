import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Send, UserPlus, ArrowUpDown, TrendingUp } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

interface WalletBalanceProps {
  userId: number;
  onSend: () => void;
  onReceive: () => void;
}

export default function WalletBalance({ userId, onSend, onReceive }: WalletBalanceProps) {
  const { data: wallets, isLoading: walletsLoading } = useQuery({
    queryKey: ["/api/wallets", userId],
  });

  const { data: prices, isLoading: pricesLoading } = useQuery({
    queryKey: ["/api/prices"],
  });

  const isLoading = walletsLoading || pricesLoading;

  const calculateTotalBalance = () => {
    if (!wallets || !prices) return 0;
    
    return wallets.reduce((total: number, wallet: any) => {
      const price = prices[wallet.currency] || 0;
      const balance = parseFloat(wallet.balance) || 0;
      return total + (balance * price);
    }, 0);
  };

  const totalBalance = calculateTotalBalance();

  if (isLoading) {
    return (
      <section className="p-6 crypto-gradient mx-4 rounded-2xl shadow-xl mb-6">
        <div className="text-center">
          <Skeleton className="h-4 w-24 mx-auto mb-2 bg-white/20" />
          <Skeleton className="h-10 w-48 mx-auto mb-1 bg-white/20" />
          <Skeleton className="h-4 w-32 mx-auto bg-white/20" />
        </div>
      </section>
    );
  }

  return (
    <section className="p-6 crypto-gradient mx-4 rounded-2xl shadow-xl mb-6">
      <div className="text-center">
        <p className="text-blue-100 text-sm font-medium mb-2">Total Balance</p>
        <h2 className="text-4xl font-bold text-white mb-1">
          ${totalBalance.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
        </h2>
        <p className="text-blue-200 text-sm">
          <span className="inline-flex items-center">
            <TrendingUp className="w-4 h-4 mr-1" />
            +2.45% (24h)
          </span>
        </p>
      </div>
      
      <div className="flex justify-center space-x-4 mt-6">
        <Button
          onClick={onSend}
          className="flex flex-col items-center bg-white/20 backdrop-blur-sm rounded-xl p-4 hover:bg-white/30 transition-colors h-auto border-0"
          variant="ghost"
        >
          <Send className="w-6 h-6 text-white mb-2" />
          <span className="text-white text-sm font-medium">Send</span>
        </Button>
        
        <Button
          onClick={onReceive}
          className="flex flex-col items-center bg-white/20 backdrop-blur-sm rounded-xl p-4 hover:bg-white/30 transition-colors h-auto border-0"
          variant="ghost"
        >
          <UserPlus className="w-6 h-6 text-white mb-2" />
          <span className="text-white text-sm font-medium">Receive</span>
        </Button>
        
        <Button
          className="flex flex-col items-center bg-white/20 backdrop-blur-sm rounded-xl p-4 hover:bg-white/30 transition-colors h-auto border-0"
          variant="ghost"
        >
          <ArrowUpDown className="w-6 h-6 text-white mb-2" />
          <span className="text-white text-sm font-medium">Swap</span>
        </Button>
      </div>
    </section>
  );
}
