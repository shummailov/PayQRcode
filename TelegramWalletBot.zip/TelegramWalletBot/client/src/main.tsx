import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// Initialize Telegram WebApp if available
const initTelegram = () => {
  const tg = (window as any).Telegram?.WebApp;
  if (tg) {
    console.log('🚀 Telegram WebApp initializing...', {
      version: tg.version,
      platform: tg.platform,
      viewportHeight: tg.viewportHeight,
      isExpanded: tg.isExpanded,
      colorScheme: tg.colorScheme,
      initData: tg.initData ? 'Present' : 'None'
    });
    
    tg.ready();
    tg.expand();
    
    // Force app to show with aggressive positioning for Telegram
    document.documentElement.style.height = '100%';
    document.documentElement.style.width = '100%';
    document.body.style.height = '100%';
    document.body.style.width = '100%';
    document.body.style.margin = '0';
    document.body.style.padding = '0';
    document.body.style.overflow = 'hidden';
    document.body.style.position = 'fixed';
    document.body.style.top = '0';
    document.body.style.left = '0';
    document.body.style.right = '0';
    document.body.style.bottom = '0';
    
    // Make sure the app is visible with forced positioning
    const rootElement = document.getElementById('root');
    if (rootElement) {
      rootElement.style.height = '100%';
      rootElement.style.width = '100%';
      rootElement.style.position = 'fixed';
      rootElement.style.top = '0';
      rootElement.style.left = '0';
      rootElement.style.right = '0';
      rootElement.style.bottom = '0';
      rootElement.style.zIndex = '9999';
      rootElement.style.display = 'block';
      rootElement.style.visibility = 'visible';
    }
    
    tg.MainButton.hide();
    console.log('✅ Telegram WebApp setup complete');
    
    // Send a message to Telegram that we're ready
    setTimeout(() => {
      if (tg.HapticFeedback) {
        tg.HapticFeedback.impactOccurred('light');
      }
    }, 500);
  } else {
    console.log('Not running in Telegram WebApp');
  }
};

// Multiple initialization attempts
if ((window as any).Telegram?.WebApp) {
  initTelegram();
} else {
  // Wait for script to load
  const checkTelegram = () => {
    if ((window as any).Telegram?.WebApp) {
      initTelegram();
    } else {
      setTimeout(checkTelegram, 100);
    }
  };
  checkTelegram();
}

createRoot(document.getElementById("root")!).render(<App />);
