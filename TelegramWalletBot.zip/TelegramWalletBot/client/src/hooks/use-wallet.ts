import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

export function useWallet(userId: number) {
  const queryClient = useQueryClient();

  const wallets = useQuery({
    queryKey: ["/api/wallets", userId],
    enabled: !!userId,
  });

  const transactions = useQuery({
    queryKey: ["/api/transactions", userId],
    enabled: !!userId,
  });

  const prices = useQuery({
    queryKey: ["/api/prices"],
    refetchInterval: 60000, // Refetch every minute
  });

  const sendTransaction = useMutation({
    mutationFn: async (transactionData: any) => {
      const response = await apiRequest("POST", "/api/transactions", transactionData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/wallets", userId] });
      queryClient.invalidateQueries({ queryKey: ["/api/transactions", userId] });
    },
  });

  const verifyPin = useMutation({
    mutationFn: async ({ userId, pin }: { userId: number; pin: string }) => {
      const response = await apiRequest("POST", "/api/auth/verify-pin", { userId, pin });
      return response.json();
    },
  });

  const calculateTotalBalance = () => {
    if (!wallets.data || !prices.data) return 0;
    
    return wallets.data.reduce((total: number, wallet: any) => {
      const price = prices.data[wallet.currency] || 0;
      const balance = parseFloat(wallet.balance) || 0;
      return total + (balance * price);
    }, 0);
  };

  return {
    wallets: wallets.data,
    transactions: transactions.data,
    prices: prices.data,
    isLoading: wallets.isLoading || transactions.isLoading || prices.isLoading,
    sendTransaction,
    verifyPin,
    totalBalance: calculateTotalBalance(),
  };
}
